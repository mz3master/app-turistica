
function navigateTo(page) {
  const content = document.getElementById("content");
  if (page === "map") {
    content.innerHTML = "<h2>Mapa Turístico</h2><p>Exibe pontos turísticos com imagem e localização.</p>";
  } else if (page === "lodging") {
    content.innerHTML = "<h2>Alojamentos</h2><p>Lista de hotéis e casas com imagem, preço e botão reservar.</p>";
  } else if (page === "route") {
    content.innerHTML = "<h2>Rota e Calendário</h2><p>Mostra uma rota personalizada com eventos e horários.</p>";
  } else if (page === "profile") {
    content.innerHTML = "<h2>Perfil</h2><p>Favoritos, reservas, histórico e preferências de idioma.</p>";
  }
}

// Registo do Service Worker
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('service-worker.js')
    .then(() => console.log('Service Worker registado com sucesso!'))
    .catch(err => console.error('Erro ao registar Service Worker:', err));
}
